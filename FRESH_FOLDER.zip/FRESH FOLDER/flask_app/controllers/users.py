from flask_app import app, bcrypt
from flask import render_template,redirect,request,session,flash
from flask_app.controllers import users
# from flask_app.models import

@app.route("/")
def main():
    if 'first_name' not in session:
        session['first_name'] = None
    if 'last_name' not in session:
        session['last_name'] = None
    if 'email' not in session:
        session['email'] = None
    return render_template("index.html", first_name = session['first_name'], last_name = session['last_name'], email = session['email'], )

